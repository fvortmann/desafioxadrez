import os
import time
import pyautogui
import MyUtils

mX, mY = pyautogui.position() # Returns two integers, the x and y of the mouse cursor's current position.
print(mX, mY)

viewCenter = laptopLeft = laptopOnly = False #Lembrando que números, strings e booleanos não são refeências, como dicionários e listas.

#viewCenter = True
#laptopLeft = True
laptopOnly = True

tempoEspera = 60 #4*60+50 #esperar por segundos informados

if laptopOnly : 
    moveToXcompartilhado = 950
    moveToXchat = 1035
    moveToY = 75
    print("laptopOnly")

elif laptopLeft : #monitor W541 a esquerda x,y
    moveToXcompartilhado = -1100
    moveToXchat = -1165
    moveToY = 90
    print("monitor W541 a esquerda x,y")
    
else: #monitor 27polegadas centro x,y
    moveToXcompartilhado = 745
    moveToXchat = 680
    moveToY = 70
    print("monitor 27polegadas centro x,y")

def runJob():
    moverJob = 0;
    while(moverJob<2920):
        print("JOB: ",  "start")                
        moverJob += 1;
        varTempMouse = MyUtils.getVAR('move');
        print("JOB: ", varTempMouse)
        if(True): #varTempMouse == 'Iniciar'):
            pyautogui.moveTo(moveToXcompartilhado, moveToY, duration=1, tween=pyautogui.easeInOutQuad)
            pyautogui.click();
            time.sleep(tempoEspera)
            pyautogui.moveTo(moveToXchat, moveToY, duration=1, tween=pyautogui.easeInOutQuad)
            pyautogui.click();
            continue;
        elif (varTempMouse=='Parar'):
            time.sleep(tempoEspera)
            continue;
        else:
            pyautogui.moveTo(400, 60, duration=1, tween=pyautogui.easeInOutQuad)
            time.sleep(tempoEspera)
            break;    

runJob()