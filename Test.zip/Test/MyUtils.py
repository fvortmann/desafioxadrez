import os
import configparser

pathFile = "file.properties"; #ver depois como mudar path do file.

config = configparser.ConfigParser()

def start():
    config['VARIAVEIS'] = {}
    config['VARIAVEIS']['move'] = 'True'
    with open(pathFile, 'w') as configfile:
        config.write(configfile)

def getVAR(name):    
    config.read(pathFile)
    valor = config['VARIAVEIS'][name]
    return valor;

def setVAR(name, value):
    config['VARIAVEIS'][name]=value;
    with open(pathFile, 'w') as configfile:
        config.write(configfile)
        configfile.close()

# print(getVAR('move'));
# setVAR('move', "Testeaaa")
# print(getVAR('move'));